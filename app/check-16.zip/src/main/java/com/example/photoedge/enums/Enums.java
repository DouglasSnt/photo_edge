package com.example.photoedge.enums;

public class Enums {
    public enum TransformationState {
        EDITING,
        CONFIRM_TRANSFORMATION,
        CANCEL_TRANSFORMATION,
        CONFIRM_CROP,
        CANCEL_CROP
    }

}
