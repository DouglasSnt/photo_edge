package com.example.photoedge.ui.fragments.canvas;

import androidx.fragment.app.Fragment;

import com.example.photoedge.R;

public class EmptyToolFragment extends Fragment {

    public EmptyToolFragment() {
        super(R.layout.fragment_empty);
    }

}
