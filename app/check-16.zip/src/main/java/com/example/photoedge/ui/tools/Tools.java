package com.example.photoedge.ui.tools;

public interface Tools {

    int BRUSH_TOOl = 0;
    int ERASER_TOOL = 1;
    int BLUR_TOOL = 2;
    int RESIZE_TOOL = 3;
    int TRANSFORMATION_TOOL = 4;
    int SELECT_BOX_TOOL = 5;
    int CROP_TOOL = 6;
    int ZOOM_TOOL = 7;
    int LAYER_TOOL = 8;
    int EMPTY_TOOL = 9;

}
